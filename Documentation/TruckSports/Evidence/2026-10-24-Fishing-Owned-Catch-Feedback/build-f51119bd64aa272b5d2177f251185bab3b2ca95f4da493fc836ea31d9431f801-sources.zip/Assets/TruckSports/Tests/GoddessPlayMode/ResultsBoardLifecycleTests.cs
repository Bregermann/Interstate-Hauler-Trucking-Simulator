#if UNITY_EDITOR
using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

public sealed class ResultsBoardLifecycleTests
{
    const BindingFlags Any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    static Type Runtime(string name) => Type.GetType("LWS.TruckSports." + name + ", Assembly-CSharp", true);
    static object Get(object owner, string name) => owner.GetType().GetField(name, Any) is FieldInfo field ? field.GetValue(owner) : owner.GetType().GetProperty(name, Any).GetValue(owner);
    static void Set(object owner, string name, object value) => owner.GetType().GetField(name, Any).SetValue(owner, value);
    static object Call(object owner, string name, params object[] args) => owner.GetType().GetMethods(Any).Single(method => method.Name == name && method.GetParameters().Length == args.Length).Invoke(owner, args);
    static Rect Bounds(RectTransform rect) { var corners = new Vector3[4]; rect.GetWorldCorners(corners); return Rect.MinMaxRect(corners.Min(v => v.x), corners.Min(v => v.y), corners.Max(v => v.x), corners.Max(v => v.y)); }
    [UnityTest, Timeout(180000)] public IEnumerator SyntheticEveryMountainRosterKeepsRanksAndControlsScreenSafe() { for (int count = 1; count <= 12; count++) yield return Inspect("TruckAvalancheEscape", count); }
    [UnityTest, Timeout(180000)] public IEnumerator SyntheticEveryNinjaRosterKeepsActualDataAndControlsScreenSafe() { for (int count = 1; count <= 8; count++) yield return Inspect("TruckNinjaWarrior", count); }
    [UnityTest, Timeout(60000)] public IEnumerator SyntheticSixAthleteResultsLeaveReplayNavigationClear() { yield return Inspect("TruckNinjaWarrior", 6); }
    static IEnumerator Inspect(string scene, int count)
    {
        var scope = (IDisposable)Runtime("SportsPrefs").GetMethod("IsolateValidation").Invoke(null, new object[] { "SyntheticResultsGeometry" });
        var isolation = new GameObject("Explicit synthetic rules and real saved results UI fixture"); UnityEngine.Object.DontDestroyOnLoad(isolation); isolation.AddComponent(Runtime("SportsProbeInputIsolation")); Component match = null;
        try
        {
            EditorSceneManager.LoadSceneInPlayMode("Assets/" + scene + "/Scenes/" + scene + ".unity", new LoadSceneParameters(LoadSceneMode.Single)); yield return null; yield return null;
            match = (Component)UnityEngine.Object.FindAnyObjectByType(Runtime("SportsEventSession")); var setup = Get(match, "setup"); Set(setup, "count", count); Call(match, "AllBots");
            foreach (object player in ((Array)Get(setup, "players")).Cast<object>().Take(count)) Set(player, "name", "Duplicate Name");
            Assert.That(Call(match, "StartMatch"), Is.True); ((Behaviour)match).enabled = false;
            var rules = Get(match, "rules");
            if (scene == "TruckAvalancheEscape")
            {
                Call(rules, "Tick", 63f);
                for (int i = 0; i < count; i++) Assert.That(Call(rules, "Finish", i, i < 2 ? 40f : 40f + i), Is.True);
            }
            else
            {
                for (int i = 0; i < count; i++)
                {
                    Call(rules, "Tick", 3f);
                    int checkpoints = i < 2 ? 6 : 1 + i % 5;
                    for (int checkpoint = 1; checkpoint <= checkpoints; checkpoint++) Assert.That(Call(rules, "Clear", i, checkpoint), Is.True);
                    if (i < 2) { Call(rules, "Tick", 35f); if (i == 1) Assert.That(Call(rules, "Fall", i), Is.True); Assert.That(Call(rules, "Bell", i), Is.True); }
                    else Call(rules, "Tick", 180f);
                    Call(rules, "Tick", 3f);
                }
            }
            Call(match, "EndMatch"); yield return null; yield return null;
            var board = (Component)UnityEngine.Object.FindAnyObjectByType(Runtime("SportsResultsPresentation")); Assert.That(board, Is.Not.Null); Call(board, "CompleteAnimations"); Canvas.ForceUpdateCanvases();
            Assert.That(Get(board, "Displaying"), Is.True); var snapshot = Get(board, "Snapshot"); var entries = ((IEnumerable)Get(snapshot, "Rows")).Cast<object>().ToArray(); Assert.That(entries.Length, Is.EqualTo(count));
            Assert.That(entries.Select(entry => Get(entry, "ParticipantId")).Distinct().Count(), Is.EqualTo(count)); Assert.That(entries.All(entry => (string)Get(entry, "DisplayName") == "Duplicate Name"), Is.True);
            Assert.That(entries.Count(entry => (bool)Get(entry, "Winner")), Is.EqualTo(scene == "TruckAvalancheEscape" ? Math.Min(2, count) : 1));
            var views = ((Array)Get(board, "rows")).Cast<object>().Where(view => ((Component)Get(view, "rect")).gameObject.activeSelf).ToArray(); Assert.That(views.Length, Is.EqualTo(count));
            for (int i = 0; i < entries.Length; i++)
            {
                int slot = (int)Get(entries[i], "Slot"); Assert.That(Get(entries[i], "Place"), Is.EqualTo(Call(rules, "Place", slot)));
                Assert.That(Get(Get(views[i], "value"), "text"), Is.EqualTo(Get(entries[i], "Value")));
                if (scene == "TruckNinjaWarrior") { bool finished = ((bool[])Get(rules, "finished"))[slot]; Assert.That(Get(entries[i], "Measurement"), Is.EqualTo(finished ? (double?)((float[])Get(rules, "adjustedTime"))[slot] : null)); }
            }
            var menus = (Component)Get(match, "menus"); var page = ((GameObject[])Get(menus, "pages"))[6];
            Action<Camera> inspect = camera =>
            {
                Canvas.ForceUpdateCanvases(); var canvasBounds = Bounds(menus.GetComponent<RectTransform>());
                foreach (var view in views)
                {
                    Rect valueBounds = Bounds(((Component)Get(view, "value")).GetComponent<RectTransform>()), detailBounds = Bounds(((Component)Get(view, "detail")).GetComponent<RectTransform>());
                    Assert.That(valueBounds.Overlaps(detailBounds), Is.False, "Primary result and statistics need separate vertical text lanes.");
                    foreach (string field in new[] { "name", "value", "detail" }) { var label = Get(view, field); Call(label, "ForceMeshUpdate", false, false); Assert.That(Get(label, "isTextOverflowing"), Is.False, "Actual result label must fit: " + field); }
                    Rect row = Bounds((RectTransform)Get(view, "rect")); Assert.That(row.xMin, Is.GreaterThanOrEqualTo(canvasBounds.xMin)); Assert.That(row.xMax, Is.LessThanOrEqualTo(canvasBounds.xMax)); Assert.That(row.yMin, Is.GreaterThanOrEqualTo(canvasBounds.yMin)); Assert.That(row.yMax, Is.LessThanOrEqualTo(canvasBounds.yMax));
                    foreach (var action in page.GetComponentsInChildren(Runtime("SportsMenuAction"), true).Cast<Component>()) Assert.That(row.Overlaps(Bounds(action.GetComponent<RectTransform>())), Is.False, "Ranked rows must not cover rematch/replay navigation.");
                    foreach (string heading in new[] { "Title", "Subtitle" }) Assert.That(row.Overlaps(Bounds(page.transform.Find(heading).GetComponent<RectTransform>())), Is.False);
                }
                for (int i = 0; i < views.Length; i++) for (int j = i + 1; j < views.Length; j++) Assert.That(Bounds((RectTransform)Get(views[i], "rect")).Overlaps(Bounds((RectTransform)Get(views[j], "rect"))), Is.False);
            };
            var save = Runtime("SportsControlledCapture").GetMethods().Single(method => method.Name == "Save" && method.GetParameters().Length == 5);
            foreach (var dimensions in new[] { new Vector2Int(1280,720), new Vector2Int(1920,1080) }) save.Invoke(null, new object[] { match, dimensions.x, dimensions.y, "Logs/TruckSports/PlaytestRepair/ResultsBoard/" + scene + "-" + count + "-" + dimensions.y + ".png", inspect });
            ((Behaviour)match).enabled = true; Call(match, "SetupScreen"); Assert.That(Get(board, "Snapshot"), Is.Null); Assert.That(Call(match, "StartMatch"), Is.True); yield return null; Assert.That(Get(board, "Snapshot"), Is.Null);
            TestContext.WriteLine("SYNTHETIC_RESULTS_GEOMETRY " + scene + " count=" + count + ": explicit rule finish/timeout values, real saved Heat page and DOTween UI; duplicate names, authoritative ranks/ties/penalties, controlled720/1080 bounds, rematch. Not physical-match acceptance.");
        }
        finally { if (match != null) { ((Behaviour)match).enabled = true; Call(match, "SetupScreen"); } Time.timeScale = 1; UnityEngine.Object.DestroyImmediate(isolation); scope.Dispose(); }
    }
}
#endif
