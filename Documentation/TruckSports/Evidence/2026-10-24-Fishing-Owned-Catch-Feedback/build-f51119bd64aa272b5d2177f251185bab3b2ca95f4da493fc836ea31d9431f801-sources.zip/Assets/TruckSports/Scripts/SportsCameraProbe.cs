#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;using System.IO;using System.Collections;using System.Collections.Generic;using System.Linq;using System.Text;
using UnityEngine;using UnityEngine.Rendering;using UnityEngine.InputSystem;using UnityEngine.SceneManagement;using LWS.TruckBowling;
using UnityEngine.UI;using TMPro;
namespace LWS.TruckSports {
public sealed class SportsCameraProbe:MonoBehaviour {
 [RuntimeInitializeOnLoadMethod]static void Boot(){bool run=Array.IndexOf(Environment.GetCommandLineArgs(),"-tsCameraOptions")>=0;
#if UNITY_EDITOR
 run|=UnityEditor.SessionState.GetBool("Sports.CameraProbe",false);UnityEditor.SessionState.SetBool("Sports.CameraProbe",false);
#endif
 if(!run)return;var go=new GameObject("Explicit camera presentation acceptance");DontDestroyOnLoad(go);if(!SportsProbeInputIsolation.Active)go.AddComponent<SportsProbeInputIsolation>();go.AddComponent<SportsCameraProbe>();}
 [Serializable]sealed class PreferenceSnapshot{public bool had;public int value;}
 string folder;int errors,checks,scenes;bool finished,hadPreference;int previous;float started;InputSettings original,isolated;Keyboard keyboard;readonly Gamepad[] testPads=new Gamepad[4];readonly StringBuilder log=new StringBuilder();readonly Dictionary<string,string> saved=new Dictionary<string,string>();readonly HashSet<string> had=new HashSet<string>();
 void Check(bool ok,string label){checks++;log.AppendLine((ok?"PASS ":"FAIL ")+label);if(!ok)errors++;File.WriteAllText(folder+"/progress.txt",log.ToString());}
 void Error(string message,string stack,LogType type){if(type!=LogType.Error&&type!=LogType.Exception)return;errors++;log.AppendLine("ERROR "+message);File.WriteAllText(folder+"/progress.txt",log.ToString());}
 void SaveKey(string key){if(saved.ContainsKey(key))return;if(SportsPrefs.HasKey(key))had.Add(key);saved[key]=SportsPrefs.GetString(key);}
 bool OwnsHud(SportsEventSession sport,int view,int expected,Func<int,string> legacy){
  if(sport==null)return legacy==null;
  if(sport.TryReadViewportCard(view,out int owner,out _,out _)){
   var root=sport.menus.viewPanels[view].Find("Compact owned viewport score");var name=root?.Find("Participant name")?.GetComponent<TMP_Text>();
   return owner==expected&&root!=null&&root.gameObject.activeInHierarchy&&name!=null&&name.text==sport.ViewportCardLabel(view,owner);
  }
  var minimal=sport.GetComponent<SportsExpansionViewHud>();
  if(minimal!=null&&minimal.minimalDistance){
   var roster=minimal.views!=null?minimal.views.rally:minimal.rally;var panel=sport.menus.viewPanels[view];var portrait=panel.Find("Assigned truck portrait")?.GetComponent<Image>();var stripe=panel.Find("Assigned participant color")?.GetComponent<Image>();
   var color=sport.setup.players[expected].color;
   return roster!=null&&roster.owners[view]==expected&&portrait!=null&&portrait.gameObject.activeInHierarchy&&portrait.sprite!=null&&stripe!=null&&stripe.color==color&&portrait.color==Color.Lerp(color,Color.white,.25f)&&sport.menus.viewTexts[view].text==sport.ViewText(view);
  }
  return legacy!=null&&legacy(view).Contains(sport.setup.players[expected].name);
 }
 IEnumerator DiagnoseSky(SportsEventSession sport,string scene,Canvas canvas,Func<Camera[]> cameras){
  var weather=FindAnyObjectByType<SportsChaosWeather>();Check(weather!=null&&weather.clouds!=null,scene+" explicit sky diagnostic finds the installed weather authority");if(weather==null||weather.clouds==null)yield break;
  SaveKey(SportsWeatherPresets.PreferenceKey);foreach(var preset in weather.presets.entries)if(preset.displayName=="Clear"){weather.presets.Select(preset.id);break;}
  Bind(sport.setup,4,sport);SportsCameraOptions.Set(false);bool ok=sport.StartMatch();Check(ok,scene+" four-human Clear sky diagnostic starts");if(!ok)yield break;
  yield return new WaitForSecondsRealtime(.3f);sport.Pause();sport.menus.Show(SportsEventScreen.Play);yield return null;
  yield return Capture(scene+"-sky-paused-baseline",canvas,cameras());
  sport.Resume();yield return new WaitForSecondsRealtime(1);yield return Capture(scene+"-sky-live-warm",canvas,cameras());
  sport.Pause();sport.menus.Show(SportsEventScreen.Play);yield return null;yield return Capture(scene+"-sky-paused-warm",canvas,cameras());
  weather.clouds.ForceReload();yield return null;yield return Capture(scene+"-sky-same-profile-reload",canvas,cameras());
  var vendor=weather.vendor;var previousProfile=vendor.PerformanceProfile;bool automatic=vendor.AutoSetPerformanceProfile;
  var temporary=Instantiate(previousProfile);vendor.AutoSetPerformanceProfile=false;
  try{
   temporary.VolumetricCloudTemporalReprojectionSize=DigitalRuby.WeatherMaker.WeatherMakerTemporalReprojectionSize.None;vendor.PerformanceProfile=temporary;
   yield return null;yield return Capture(scene+"-sky-no-temporal",canvas,cameras());
   vendor.PerformanceProfile=previousProfile;yield return null;
   temporary.VolumetricCloudTemporalReprojectionSize=previousProfile.VolumetricCloudTemporalReprojectionSize;
   temporary.VolumetricCloudDownsampleScale=DigitalRuby.WeatherMaker.WeatherMakerDownsampleScale.FullResolution;
   temporary.VolumetricCloudDownsampleScalePostProcess=DigitalRuby.WeatherMaker.WeatherMakerDownsampleScale.FullResolution;vendor.PerformanceProfile=temporary;
   yield return null;yield return Capture(scene+"-sky-full-resolution",canvas,cameras());
  }finally{vendor.PerformanceProfile=previousProfile;vendor.AutoSetPerformanceProfile=automatic;Destroy(temporary);}
  var views=cameras();var post=views.Select(camera=>camera.GetComponent<UnityEngine.Rendering.Universal.UniversalAdditionalCameraData>()).ToArray();var oldPost=post.Select(data=>data!=null&&data.renderPostProcessing).ToArray();
  try{foreach(var data in post)if(data!=null)data.renderPostProcessing=false;yield return null;yield return Capture(scene+"-sky-no-post",canvas,cameras());}
  finally{for(int i=0;i<post.Length;i++)if(post[i]!=null)post[i].renderPostProcessing=oldPost[i];}
  var msaa=views.Select(camera=>camera.allowMSAA).ToArray();
  try{foreach(var camera in views)camera.allowMSAA=false;yield return null;yield return Capture(scene+"-sky-no-msaa",canvas,cameras());}
  finally{for(int i=0;i<views.Length;i++)views[i].allowMSAA=msaa[i];}
  var clears=views.Select(camera=>camera.clearFlags).ToArray();var backgrounds=views.Select(camera=>camera.backgroundColor).ToArray();
  try{foreach(var camera in views){camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.magenta;}yield return null;yield return Capture(scene+"-sky-magenta-clear",canvas,cameras());}
  finally{for(int i=0;i<views.Length;i++){views[i].clearFlags=clears[i];views[i].backgroundColor=backgrounds[i];}}
  var skyShader=Resources.Load<Shader>("Viewport Weather Maker Skybox");Check(skyShader!=null,scene+" installed-algorithm skybox geometry adapter is available");
  if(skyShader!=null){var oldSky=RenderSettings.skybox;var oldQueue=weather.clouds.RenderQueue;var sky=new Material(skyShader);
   try{RenderSettings.skybox=sky;weather.clouds.RenderQueue=UnityEngine.Rendering.CameraEvent.AfterSkybox;foreach(var camera in views)camera.clearFlags=CameraClearFlags.Skybox;weather.clouds.ForceReload();yield return null;yield return Capture(scene+"-sky-vendor-skybox-path",canvas,cameras());}
   finally{RenderSettings.skybox=oldSky;weather.clouds.RenderQueue=oldQueue;for(int i=0;i<views.Length;i++)views[i].clearFlags=clears[i];weather.clouds.ForceReload();Destroy(sky);}
  }
  log.AppendLine("SKY DIAGNOSTIC: labelled Windows captures only; no corrected sky or full-match acceptance claimed.");
 }
 IEnumerator ReviewSkyWeather(SportsEventSession sport,BowlingSetup setup,Action stop,Func<bool> start,Action pause,Action playHUD,string scene,Canvas canvas,Func<Camera[]> cameras){
  var weather=FindAnyObjectByType<SportsChaosWeather>();Check(weather!=null&&weather.presets!=null&&weather.clouds!=null,scene+" saved weather bindings exist");if(weather==null||weather.presets==null||weather.clouds==null)yield break;
  SaveKey(SportsWeatherPresets.PreferenceKey);
  foreach(string label in new[]{"Clear","Heavy Rain","Snow","Blizzard","Hurricane"}){
   var preset=weather.presets.entries.FirstOrDefault(entry=>entry!=null&&entry.displayName==label);Check(preset!=null,scene+" installed preset "+label);if(preset==null)continue;
   stop();weather.presets.Select(preset.id);Bind(setup,4,sport);SportsCameraOptions.Set(false);Check(start(),scene+" four-human weather rematch starts "+label);
   yield return new WaitForSecondsRealtime(1.2f);
   Check(weather.PresetId==preset.id&&weather.vendor.LastLocalProfile!=null&&weather.vendor.LastLocalProfile!=preset.profile,scene+" actual vendor runtime profile selected "+label);
   Check(RenderSettings.skybox!=null&&RenderSettings.skybox.shader.name=="LWS/TruckSports/Weather Maker Viewport Skybox"&&weather.clouds.RenderQueue==CameraEvent.AfterSkybox&&cameras().All(camera=>camera.clearFlags==CameraClearFlags.Skybox),scene+" saved sky coverage path retained "+label);
   pause();playHUD();yield return null;yield return Capture(scene+"-weather-"+label.Replace(' ','-'),canvas,cameras());
  }
 }
 void Bind(BowlingSetup setup,int humans,SportsEventSession sport){setup.mode=BowlingMode.Simultaneous;setup.sharedHotSeat=false;var defaults=BowlingSetup.Defaults();for(int i=0;i<setup.count;i++){var p=setup.players[i];p.name="Alexandria Montgomery Smythe "+(i+1);p.source=BowlingSource.AI;p.pad=null;int h=i-(setup.count-humans);if(h<0)continue;if(sport is LWS.TruckPedestrianPlowing.PlowMatch){p.source=BowlingSource.WholeController;p.pad=testPads[h];continue;}p.source=BowlingSource.Keyboard;p.forward=defaults[h].forward;p.back=defaults[h].back;p.left=defaults[h].left;p.right=defaults[h].right;if(sport!=null)sport.actionKeys[i]=new[]{Key.F1,Key.F2,Key.F3,Key.F4}[h];}}
 IEnumerator Capture(string name,Canvas canvas,Camera[] cameras){
  if(Application.isEditor){Check(true,"Editor images not used as actual Windows captures "+name);yield break;}
  var plow=FindAnyObjectByType<LWS.TruckPedestrianPlowing.PlowMatch>();bool cab=plow!=null&&plow.option==2&&plow.Running&&!plow.ReplayControls;
  var seen=new HashSet<Camera>();var restored=new HashSet<Camera>();
  void Begin(ScriptableRenderContext context,Camera camera){
   if(!cab||!cameras.Contains(camera)||!seen.Add(camera))return;
   int v=Array.FindIndex(plow.views.rally.views,c=>c.view==camera);if(v<0)return;int owner=plow.views.Owner(v);
   Check(plow.trucks[owner].visuals.GetComponentsInChildren<Renderer>(true).All(r=>r.forceRenderingOff),name+" actual cab render hides only its own exterior "+owner);
   for(int i=0;i<plow.setup.count;i++)if(i!=owner)Check(plow.trucks[i].visuals.GetComponentsInChildren<Renderer>(true).All(r=>!r.forceRenderingOff),name+" other competitor exterior remains visible "+i);
  }
  void End(ScriptableRenderContext context,Camera camera){if(!cab||!cameras.Contains(camera)||!restored.Add(camera))return;Check(plow.trucks.SelectMany(t=>t.visuals.GetComponentsInChildren<Renderer>(true)).All(r=>!r.forceRenderingOff),name+" render restores exteriors for other views and GPS");}
  if(cab){for(int v=0;v<cameras.Length;v++){int owner=plow.views.Owner(v);var forward=Vector3.ProjectOnPlane(plow.trucks[owner].body.rotation*Vector3.forward,Vector3.up);Check(Quaternion.Angle(plow.views.cabRoots[v].rotation,Quaternion.LookRotation(forward))<3,name+" new owner starts with aligned stable cab heading "+owner);}RenderPipelineManager.beginCameraRendering+=Begin;RenderPipelineManager.endCameraRendering+=End;}
  try{foreach(var size in new[]{new Vector2Int(1280,720),new Vector2Int(1920,1080)}){Screen.SetResolution(size.x,size.y,false);yield return new WaitForSecondsRealtime(.35f);Check(Screen.width==size.x&&Screen.height==size.y,"actual window "+size);ScreenCapture.CaptureScreenshot(folder+"/"+name+"-"+size.x+".png");yield return new WaitForSecondsRealtime(.12f);}if(cab)Check(seen.Count==cameras.Length&&restored.Count==cameras.Length,name+" all selected cab cameras rendered and restored");}
  finally{if(cab){RenderPipelineManager.beginCameraRendering-=Begin;RenderPipelineManager.endCameraRendering-=End;}}
 }

 IEnumerator Start(){var args=Environment.GetCommandLineArgs();int output=Array.IndexOf(args,"-tsCameraOutput");folder=output>=0?Path.GetFullPath(args[output+1]):SportsEvidencePaths.Folder("Party/CameraOptions");Directory.CreateDirectory(folder);started=Time.realtimeSinceStartup;bool write=Array.IndexOf(args,"preference-write")>=0,read=Array.IndexOf(args,"preference-read")>=0;if(write||read){string path=folder+"/preference-restore.json";if(write){File.WriteAllText(path,JsonUtility.ToJson(new PreferenceSnapshot{had=SportsPrefs.HasKey(SportsCameraOptions.PreferenceKey),value=SportsPrefs.GetInt(SportsCameraOptions.PreferenceKey)}));SportsCameraOptions.Set(true);Check(SportsCameraOptions.ShowAI,"ON saved for an independent subsequent player process");}else{Check(SportsCameraOptions.ShowAI,"ON restored after actual application restart");if(File.Exists(path)){var snapshot=JsonUtility.FromJson<PreferenceSnapshot>(File.ReadAllText(path));if(snapshot.had)SportsPrefs.SetInt(SportsCameraOptions.PreferenceKey,snapshot.value);else SportsPrefs.DeleteKey(SportsCameraOptions.PreferenceKey);SportsPrefs.Save();File.Delete(path);}else Check(false,"preference restoration receipt exists");}donePreference();yield break;}File.WriteAllText(folder+"/result.txt","RUNNING "+DateTime.UtcNow.ToString("O")+" PID="+System.Diagnostics.Process.GetCurrentProcess().Id);original=InputSystem.settings;isolated=Instantiate(original);isolated.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
#if UNITY_EDITOR
 isolated.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
#endif
 InputSystem.settings=isolated;keyboard=InputSystem.AddDevice<Keyboard>("Camera validation keyboard");for(int i=0;i<4;i++)testPads[i]=InputSystem.AddDevice<Gamepad>("Camera validation pad "+i);hadPreference=SportsPrefs.HasKey(SportsCameraOptions.PreferenceKey);previous=SportsPrefs.GetInt(SportsCameraOptions.PreferenceKey);Application.logMessageReceived+=Error;
 string[] selectedScenes={"TruckBowling","TruckCornhole","TruckCheeseRolling","TruckKeepawayFirstPerson","TruckTerrierRacing","TruckBaseJumping","TruckBungeeDemolition","TruckFishing","TruckTargetLaunch","TruckBuzkashi","TruckSkeeBall","TruckMinefield","TruckMattressRacing","TruckWifeCarrying","TruckBogSnorkelling","TruckTrampolineDodgeball","TruckDemolitionDerby","TruckPoker","TruckPedestrianPlowing","TruckPedestrianPlowingFirstPerson"};
 // Optional explicit subset keeps targeted regression runs from reopening
 // unrelated sports. Defaults retain the original twenty-scene acceptance.
 int subset=Array.IndexOf(args,"-tsCameraScenes");if(subset>=0){var requested=args[subset+1].Split(',').Distinct().ToArray();if(requested.Length==0||requested.Any(scene=>!selectedScenes.Contains(scene)))throw new ArgumentException("Camera acceptance subset contains an unsupported saved scene.");selectedScenes=requested;}
 foreach(string scene in selectedScenes){
 SportsNavigation.LoadSport(scene);yield return null;yield return null;yield return new WaitForSecondsRealtime(.15f);scenes++;
 var bowling=FindAnyObjectByType<BowlingMatch>();var corn=FindAnyObjectByType<LWS.TruckCornhole.CornholeMatch>();var cheese=FindAnyObjectByType<LWS.TruckCheeseRolling.CheeseMatch>();var sport=FindAnyObjectByType<SportsEventSession>();BowlingSetup setup=null;SportsMenuView menu=null;Action stop=null,pause=null,playHUD=null;Func<bool> start=null;Func<Camera[]> cameras=null;Func<int,string> hud=null;
 if(bowling!=null){SaveKey(BowlingMatch.SetupKey);setup=bowling.setup;setup.count=4;menu=bowling.menus;stop=bowling.ChangeSetup;pause=()=>bowling.Pause();playHUD=()=>bowling.menus.Show(BowlingScreen.Play);start=bowling.StartMatch;cameras=()=>bowling.lanes.Where(l=>l.cab.view.enabled).Select(l=>l.cab.view).ToArray();}
 else if(corn!=null){SaveKey(LWS.TruckCornhole.CornholeMatch.SetupKey);setup=corn.setup;setup.count=4;menu=corn.menus;stop=corn.ChangeSetup;pause=()=>corn.Pause();playHUD=()=>corn.menus.Show(LWS.TruckCornhole.CornholeScreen.Play);start=corn.StartMatch;cameras=()=>corn.courses.Where(c=>c.chase.view.enabled).Select(c=>c.chase.view).ToArray();}
 else if(cheese!=null){SaveKey(LWS.TruckCheeseRolling.CheeseMatch.SetupKey);setup=cheese.setup;setup.count=4;menu=cheese.menus;stop=cheese.ChangeSetup;pause=()=>cheese.Pause();playHUD=()=>cheese.menus.Show(LWS.TruckCheeseRolling.CheeseScreen.Play);start=cheese.StartMatch;cameras=()=>cheese.cameras.Where(c=>c.view.enabled).Select(c=>c.view).ToArray();}
 else if(sport!=null){SaveKey(sport.PreferenceKey);sport.SetupScreen();sport.setup.count=sport.MaximumPlayers;if(sport.TeamSport)sport.teamA=sport.teamB=4;if(sport is LWS.TruckDodgeball.DodgeMatch||sport is LWS.TruckBuzkashi.BuzMatch)sport.option=1;else if(sport is LWS.TruckTerrierRacing.TerrierMatch||sport is LWS.TruckDerby.DerbyMatch||sport is LWS.TruckSkeeBall.SkeeMatch||sport is LWS.TruckPoker.PokerMatch)sport.option=0;if(sport is LWS.TruckPedestrianPlowing.PlowMatch plow)sport.option=plow.cabExperience?2:1;sport.NormalizeSetup();setup=sport.setup;menu=sport.menus;stop=sport.SetupScreen;pause=()=>sport.Pause();playHUD=()=>sport.menus.Show(SportsEventScreen.Play);start=sport.StartMatch;cameras=()=>sport.cameras;hud=sport.ViewText;if(sport is LWS.TruckPedestrianPlowing.PlowMatch pp)hud=index=>{pp.hud.Refresh();return pp.hud.summary[index].text;};}
 if(Array.IndexOf(args,"sky-diagnosis")>=0&&sport!=null){yield return DiagnoseSky(sport,scene,menu.GetComponent<Canvas>(),cameras);stop();continue;}
 if(bowling!=null)foreach(var lane in bowling.lanes){Check(lane.cab.transform.Find("Inside tiny cab")==null&&lane.cab.interior.Length>0,scene+" canonical interior only; no obsolete cab geometry");foreach(var filter in lane.truck.exterior.GetComponentsInChildren<MeshFilter>(true))if(filter.name=="Cab")Check(Vector3.Distance(lane.truck.body.position,filter.transform.TransformPoint(filter.sharedMesh.bounds.center))<1.25f,scene+" visual truck aligned with authoritative chassis "+lane.index);foreach(var wheel in lane.truck.wheels)Check(wheel.wheel.rotatingContainer!=null&&wheel.wheel.rotatingContainer.GetComponentInChildren<MeshRenderer>()!=null,scene+" native rolling wheel mesh bound");}Check(setup!=null&&start!=null,scene+" saved mode loaded");if(setup==null)continue;Check(menu.GetComponentInChildren<SportsCameraSetupControl>(true)!=null,scene+" actual Heat setup control installed");SportsCameraOptions.Set(false);menu.Action("aicameras");Check(SportsCameraOptions.ShowAI,scene+" real setup action turns AI views ON");menu.Action("aicameras");Check(!SportsCameraOptions.ShowAI,scene+" real setup action turns AI views OFF");
 for(int humans=0;humans<=4;humans++)for(int enabled=0;enabled<=1;enabled++){
 stop();Bind(setup,humans,sport);SportsCameraOptions.Set(enabled!=0);yield return null;Check(SportsPrefs.GetInt(SportsCameraOptions.PreferenceKey)==enabled,scene+" saved preference "+enabled);bool ok=start();Check(ok,scene+" starts humans="+humans+" AI views="+enabled);if(!ok)continue;yield return new WaitForSeconds(.06f);pause();playHUD();yield return null;var active=cameras().Where(c=>c.enabled).ToArray();int[] expected=new int[4];int count=SportsCameraOptions.Select(setup,expected,sport is LWS.TruckWifeCarrying.WifeMatch?new[]{0,1,2,3,0,1,2,3}:null);int visible=Math.Max(1,count);Check(active.Length==visible,scene+" selected view count "+humans+"/"+enabled+" actual="+active.Length+" expected="+visible);Check(setup.players.Take(setup.count).Count(p=>p.source!=BowlingSource.AI)==humans,scene+" camera preference preserves human and AI participation");
 for(int v=0;v<visible;v++){var rect=LWS.TruckCornhole.CornholeMatch.ViewRect(visible,v);var matches=active.Where(c=>c.rect==rect).ToArray();Check(matches.Length==1,scene+" unique correct rectangle "+v);if(v<count&&hud!=null)Check(OwnsHud(sport,v,expected[v],hud),scene+" actual HUD belongs to selected owner "+expected[v]);if(v<count&&bowling!=null)Check(bowling.lanes[expected[v]].cab.view.rect==rect&&bowling.lanes[expected[v]].cab.view.enabled,scene+" lane camera owner "+expected[v]);if(v<count&&corn!=null)Check(corn.courses[expected[v]].chase.view.rect==rect&&corn.courses[expected[v]].chase.view.enabled,scene+" course camera owner "+expected[v]);if(v<count&&cheese!=null)Check(cheese.cameras[expected[v]].view.rect==rect&&cheese.cameras[expected[v]].view.enabled,scene+" hill camera owner "+expected[v]);}
 if((humans==1&&enabled==0)||(humans==1&&enabled==1)||(humans==4&&enabled==0)||(humans==0&&enabled==0))yield return Capture(scene+"-h"+humans+"-ai"+enabled,menu.GetComponent<Canvas>(),active);
 }
 int configuredOption=sport!=null?sport.option:0;
 if(Array.IndexOf(args,"sky-weather")>=0&&(sport!=null||corn!=null))yield return ReviewSkyWeather(sport,setup,stop,start,pause,playHUD,scene,menu.GetComponent<Canvas>(),cameras);
 if(sport is LWS.TruckPedestrianPlowing.PlowMatch&&!(sport is LWS.TruckPedestrianPlowing.PlowCabMatch)||sport is LWS.TruckDodgeball.DodgeMatch||sport is LWS.TruckBuzkashi.BuzMatch||sport is LWS.TruckDerby.DerbyMatch||sport is LWS.TruckPoker.PokerMatch||sport is LWS.TruckSkeeBall.SkeeMatch){stop();Bind(setup,0,sport);sport.option=sport is LWS.TruckPoker.PokerMatch||sport is LWS.TruckSkeeBall.SkeeMatch||sport is LWS.TruckDerby.DerbyMatch?1:0;SportsCameraOptions.Set(true);Check(start(),scene+" shared/hot-seat starts with AI preference ON");pause();playHUD();yield return null;Check(cameras().Count(c=>c.enabled)==1,scene+" shared/hot-seat retains exactly one view");var control=menu.GetComponentInChildren<SportsCameraSetupControl>(true);Check(control!=null&&!control.gameObject.activeSelf,scene+" irrelevant split option hidden");var rally=FindAnyObjectByType<SportsRallyViews>();if(rally!=null&&rally.weather!=null)Check(cameras().All(c=>rally.weather.vendor.AllowCameras.Contains(c)),scene+" weather belongs to actual shared view");}
 if(sport!=null)sport.option=configuredOption;stop();yield return null;yield return Capture(scene+"-setup",menu.GetComponent<Canvas>(),cameras());SportsNavigation.FrontEnd();yield return null;yield return null;Check(FindAnyObjectByType<SportsEventSession>()==null,scene+" exit clears match owner");
 }
 Check(scenes==selectedScenes.Length,"all explicitly selected saved modes visited: "+selectedScenes.Length);Restore();finished=true;log.AppendLine("CHECKS="+checks+" ERRORS="+errors+" SCENES="+scenes+" PID="+System.Diagnostics.Process.GetCurrentProcess().Id+". Injected keyboard, actual saved scenes and rendered Windows layouts; no hardware or human playtest.");File.WriteAllText(folder+"/result.txt",log.ToString());Debug.Log("TS_CAMERA_PROBE_FINISHED code="+(errors==0?0:2));if(!Application.isEditor)Application.Quit(errors==0?0:2);
 }
 void donePreference(){finished=true;log.AppendLine("ERRORS="+errors+" CHECKS="+checks+" PID="+System.Diagnostics.Process.GetCurrentProcess().Id+". Isolated preference restart fixture.");File.WriteAllText(folder+"/result.txt",log.ToString());Debug.Log("TS_CAMERA_PROBE_FINISHED code="+(errors==0?0:2));if(!Application.isEditor)Application.Quit(errors==0?0:2);}
 void Update(){if(!finished&&folder!=null&&(errors>0||Time.realtimeSinceStartup-started>600)){StopAllCoroutines();Restore();finished=true;log.AppendLine("ERRORS="+Math.Max(1,errors)+" INCOMPLETE");File.WriteAllText(folder+"/result.txt",log.ToString());if(!Application.isEditor)Application.Quit(2);}}
 void Restore(){Application.logMessageReceived-=Error;foreach(var p in saved){if(had.Contains(p.Key))SportsPrefs.SetString(p.Key,p.Value);else SportsPrefs.DeleteKey(p.Key);}if(hadPreference)SportsPrefs.SetInt(SportsCameraOptions.PreferenceKey,previous);else SportsPrefs.DeleteKey(SportsCameraOptions.PreferenceKey);SportsPrefs.Save();if(keyboard!=null&&keyboard.added)InputSystem.RemoveDevice(keyboard);foreach(var pad in testPads)if(pad!=null&&pad.added)InputSystem.RemoveDevice(pad);if(original!=null){InputSystem.settings=original;original=null;}if(isolated!=null){Destroy(isolated);isolated=null;}Time.timeScale=1;}
 void OnDestroy(){if(!finished)Restore();}
}
}
#endif
