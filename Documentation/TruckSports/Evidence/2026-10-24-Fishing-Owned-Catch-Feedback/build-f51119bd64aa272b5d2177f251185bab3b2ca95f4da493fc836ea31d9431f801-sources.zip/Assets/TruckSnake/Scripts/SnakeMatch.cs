using System;
using System.Text;
using UnityEngine;
using LWS.TruckSports;
using LWS.TruckBowling;
namespace LWS.TruckSnake {
 public sealed class SnakeMatch:SportsEventSession {
  public override bool BroadcastParticipantActive(int slot)=>!rules.crashed[slot];
  public LWS.TruckTaxi.TruckTaxiTrafficAdapter traffic;public LWS.TruckTaxi.TruckTaxiPedestrianPopulation pedestrians;public SnakeWorld world;public SportsEventTruck[] trucks;public SnakeConvoy[] convoys;public SnakePickup[] pickups;
  public SportsDrivingViews drivingViews;public SportsEventCamera broadcast;public SportsChaosWeather atmosphere;public SportsWeatherPresets presets;
  public Material couplerMaterial;public AudioClip horn;public AudioSource[] horns;
  [Min(.1f)]public float pickupRespawnInterval=.5f;
  public const float MinimumJumpClearanceMetres=6.096f;
  public float minimumSpeed=4.5f,cruiseSpeed=18,maximumSpeed=32;
  [Tooltip("Full-lock human turns trim the NWH speed target without allowing the train to stop.")][Range(.4f,1)]public float humanTurnSpeedScale=.65f;
  [Tooltip("Upward takeoff speed in m/s. The arcade jump enforces lift for at least 20 feet above level road.")]public float jumpVelocity=13.5f;
  public float jumpCooldown=2.2f;
  public readonly SnakeRules rules=new SnakeRules();public readonly SnakeRouteAI[] drivers={new SnakeRouteAI(),new SnakeRouteAI(),new SnakeRouteAI(),new SnakeRouteAI()};
  public float Intro{get;private set;}public int PhysicalPickups{get;private set;}public int PhysicalJumps{get;private set;}public int RecycledPickups{get;private set;}
  readonly Vector3[] previous=new Vector3[4],jumpStart=new Vector3[4];readonly float[] jumpedAt=new float[4],nextJump=new float[4],stuck=new float[4],nextHorn=new float[4];readonly bool[] jumping=new bool[4];
  readonly int[] best=new int[4];readonly float[] moved=new float[4];readonly string[] failure=new string[4];readonly StringBuilder text=new StringBuilder();
  System.Random random;float nextPickup;string notice;float noticeUntil;int seed;
  public override string Title=>"TRUCK SNAKE";public override int MinimumPlayers=>1;public override int MaximumPlayers=>4;public override int OptionCount=>3;
  public override string OptionLabel=>new[]{"ENDLESS SNAKE","THREE-MINUTE CHALLENGE","FIVE-MINUTE CHALLENGE"}[option];
  public override bool SupportsSplitAIViews=>true;public override bool MultiViewHUD=>!drivingViews.NeedsArena;public override bool BroadcastStandingsVisible=>!MultiViewHUD;
  public override bool CompactViewportHud=>true;
  public override bool BroadcastHeaderVisible=>!MultiViewHUD;
  public override bool BroadcastStatusVisible=>!MultiViewHUD||Intro>0||Time.time<noticeUntil;
  public override bool TryReadViewportCard(int view,out int participant,out string score,out string detail){participant=-1;score=detail=null;if(drivingViews==null||view<0||view>=drivingViews.rally.Humans)return false;participant=drivingViews.rally.owners[view];if(participant<0||participant>=setup.count)return false;score=rules.score[participant].ToString();detail=CargoLabel(participant)+"\n"+(rules.crashed[participant]?"RUN ENDED":(trucks[participant].body.linearVelocity.magnitude*2.236936f).ToString("F0")+" MPH · x"+rules.ScoreMultiplier(participant));return true;}
  public override string ViewportTelemetry(int view){if(drivingViews==null||view<0||view>=drivingViews.rally.Humans)return null;int slot=drivingViews.rally.owners[view];return FareDistance(rules.distance[slot])+" · "+TimeSpan.FromSeconds(rules.survived[slot]).ToString(@"mm\:ss")+" · C"+rules.combo[slot]+" · BEST "+best[slot];}
  public override string Help=>"KEEP ROLLING. COLLECT TRAILERS. DO NOT MEET YOUR OWN TAIL.\n\nStart with one attached cargo trailer. Your semi drives continuously. Steer with your assigned movement controls. Tight turns trim the speed target while keeping the truck moving. Forward gives a modest speed increase; reverse input trims speed but cannot stop the run. ACTION launches a jump clearing at least twenty feet above level road when grounded. Forward momentum is preserved. Each trailer follows your actual three-dimensional route, so jumps travel down the road train as a delayed wave.\n\nGreen gates add ONE real cargo trailer. Gold gates add THREE. New sections join only on verified clear driven history. There is no stopping or manual coupling. Gates respawn on connected reachable roads; difficult gold routes are marked.\n\nTrailer collection, distance, survival, pickup combos and successfully landed jumps earn points multiplied by your ACTUALLY ATTACHED trailer count. One trailer = x1, ten = x10. Waiting-to-attach cargo does not increase the multiplier. Green gates are frequent along the road ahead; keep collecting to build your score faster. A serious obstacle impact or meaningful collision with your own mature tail ends your run. Minor coupling contact and attachment grace do not. Traffic and loose props can be pushed aside. Do not expect a long trailer to fit through every corner the tractor can squeeze through.\n\nOne to four simultaneous local humans/AI. Endless lasts until every run ends; timed competition ends on the clock. Finished players spectate and retain their scores. Shared player names, colors, camera preferences and input ownership apply. Rain, snow and wind come from the shared installed weather registry.\n\nChoose chase, elevated snake view or the Taxi cockpit. The elevated view follows the tractor and nearby hazards, without zooming out until the truck becomes a dot. Horn controls are shown in the viewport. No networking or powerups.";
  public override string Header=>Title+" · "+(option==0?"ENDLESS":Mathf.CeilToInt(Mathf.Max(0,rules.Seconds-rules.Clock))+"s")+" · "+atmosphere.Description;
  public override string Status=>Intro>0?Mathf.CeilToInt(Intro).ToString():Time.time<noticeUntil?notice:"GREEN +1 · GOLD +3 · JUMP WITH "+Controls(0)+" · KEEP MOVING";
  string CargoLabel(int slot)=>rules.attached[slot]+(rules.attached[slot]==1?" TRAILER":" TRAILERS");
  public override string Standings{get{text.Clear();for(int i=0;i<setup.count;i++)text.Append(setup.players[i].name).Append("  ").Append(rules.score[i]).Append(" · ").Append(CargoLabel(i)).Append(" · x").Append(rules.ScoreMultiplier(i)).Append(rules.crashed[i]?" · "+failure[i]:"").Append('\n');return text.ToString();}}
  public override string Results{get{text.Clear();for(int i=0;i<setup.count;i++)if(rules.winners[i])text.Append(setup.players[i].name).Append("  ");return text+"WIN TRUCK SNAKE!\n\n"+Standings;}}
  public override bool TryReadScoreCard(int i,out string value,out string detail){value=rules.score[i].ToString();detail=CargoLabel(i)+" · x"+rules.ScoreMultiplier(i)+" · "+(rules.crashed[i]?"RUN ENDED":"COMBO "+rules.combo[i]);return true;}
  public override string ViewText(int view){int slot=drivingViews.rally.owners[view];return setup.players[slot].name+" · "+rules.score[slot]+" PTS · BEST "+best[slot]+"\n"+CargoLabel(slot)+" · x"+rules.ScoreMultiplier(slot)+" · "+(trucks[slot].body.linearVelocity.magnitude*2.236936f).ToString("F0")+" MPH · "+FareDistance(rules.distance[slot])+"\nTIME "+System.TimeSpan.FromSeconds(rules.survived[slot]).ToString(@"mm\:ss")+" · COMBO "+rules.combo[slot]+"\n"+(rules.crashed[slot]?failure[slot]:ControlCaption(slot));}
  static string FareDistance(float distance)=>distance>1609.344f?(distance/1609.344f).ToString("F1")+" MI":Mathf.RoundToInt(distance*3.28084f)+" FT";
  protected override void BeginGame(){seed=UnityEngine.Random.Range(1,int.MaxValue);random=new System.Random(seed);rules.Start(setup.count,option==0?SnakeMode.Endless:SnakeMode.Timed,option==2?300:180);Intro=3;PhysicalPickups=PhysicalJumps=RecycledPickups=0;nextPickup=0;
   atmosphere.ConfigurePreset(presets.Resolve(seed),seed);traffic.SetRegionAvailability(world.Contains);traffic.Initialize();traffic.ResetTraffic();traffic.SetWeatherCaution(1-atmosphere.Grip);pedestrians.ResetPopulation();ConfigureKeys();
   foreach(var convoy in convoys)convoy.ResetConvoy();
   for(int i=0;i<4;i++){jumping[i]=false;stuck[i]=nextJump[i]=0;failure[i]=null;if(i>=setup.count){trucks[i].Park(new Vector3(0,-100-i*10,0));trucks[i].gameObject.SetActive(false);continue;}best[i]=SportsPrefs.GetInt("TruckSnake.Best."+setup.players[i].participantId,0);trucks[i].tractorMotor.Configure();trucks[i].Prepare(world.starts[i],world.rotations[i]);trucks[i].body.isKinematic=true;previous[i]=trucks[i].body.position;drivers[i].Reset();}
   Physics.SyncTransforms();for(int i=0;i<setup.count;i++)convoys[i].StartWithTrailer();
   foreach(var pickup in pickups)pickup.Dormant();drivingViews.Layout();SpawnPickups();
  }
  protected override void Simulate(float dt){atmosphere.Tick(Time.time);if(Intro>0){Intro-=dt;if(Intro<=0){foreach(var convoy in convoys)convoy.RebindCollisionFilters();foreach(var truck in trucks)if(truck.gameObject.activeSelf){truck.body.isKinematic=false;truck.body.WakeUp();}feedback.Play(5,0,true);}return;}
   for(int i=0;i<setup.count;i++){
    moved[i]=0;if(!rules.Playing(i)){if(trucks[i].body.position.y< -80)trucks[i].Park(new Vector3(0,-100-i*15,0));continue;}var truck=trucks[i];var body=truck.body;var p=setup.players[i];
    if(!world.Contains(body.position)||body.position.y<world.Height(body.position)-15){Fail(i,"LEFT THE PLAYABLE WORLD");continue;}
    bool ai=p.source==BowlingSource.AI;bool jump=actions[i];Vector2 drive=commands[i];if(ai)drive=drivers[i].Drive(this,i,dt,out jump);
    float forward=Vector3.Dot(body.linearVelocity,truck.transform.forward);float cruise=cruiseSpeed+rules.attached[i]*.1f;float speedTrim=drive.y>=0?drive.y*3:drive.y*Mathf.Max(0,cruise-minimumSpeed);float target=Mathf.Clamp(cruise+(ai?0:speedTrim),minimumSpeed,maximumSpeed);if(ai)target=Mathf.Clamp(drive.y,minimumSpeed,maximumSpeed);else target=Mathf.Clamp(target*Mathf.Lerp(1,humanTurnSpeedScale,Mathf.Abs(drive.x)),minimumSpeed,maximumSpeed);
    float throttle=forward<target-1?1:forward>target+1?-.6f:.3f;truck.tractorMotor.gripScale=atmosphere.Grip;truck.TickDrive(new Vector2(drive.x,throttle));
    if(jump&&truck.Grounded&&Time.time>=nextJump[i]){nextJump[i]=Time.time+jumpCooldown;jumpedAt[i]=Time.time;jumpStart[i]=body.position;jumping[i]=true;float takeoffSpeed=Mathf.Max(jumpVelocity,Mathf.Sqrt(2*Mathf.Abs(Physics.gravity.y)*(MinimumJumpClearanceMetres+1.5f)));truck.tractorMotor.AddAssemblyVelocity(Vector3.up*Mathf.Max(0,takeoffSpeed-body.linearVelocity.y));PhysicalJumps++;feedback.Play(2,0,true);Pulse(i,.15f,.1f);}
    if(!truck.Grounded){var up=body.rotation*Vector3.up;var axis=Vector3.Cross(up,Vector3.up);body.AddTorque(axis*1.8f-body.angularVelocity*.5f+Vector3.up*drive.x*.35f,ForceMode.Acceleration);body.AddForce(truck.transform.right*drive.x*.8f,ForceMode.Acceleration);}
    else if(jumping[i]&&Time.time-jumpedAt[i]>.35f){jumping[i]=false;rules.LandJump(i,Time.time-jumpedAt[i],Vector3.Distance(body.position,jumpStart[i]));}
    float distance=Vector3.Distance(body.position,previous[i]);if(distance<60)moved[i]=distance;previous[i]=body.position;
    stuck[i]=body.linearVelocity.magnitude<1?stuck[i]+dt:0;if(stuck[i]>5){Fail(i,"MAJOR COLLISION · FORWARD ROUTE BLOCKED");continue;}
    convoys[i].Tick(dt);HornAndView(i);
   }
   rules.Step(dt,moved);foreach(var pickup in pickups)pickup.Tick(dt);if(Time.time>=nextPickup){nextPickup=Time.time+Mathf.Max(.1f,pickupRespawnInterval);SpawnPickups();}
   if(rules.Complete){for(int i=0;i<setup.count;i++)if(rules.score[i]>best[i])SportsPrefs.SetInt("TruckSnake.Best."+setup.players[i].participantId,rules.score[i]);SportsPrefs.Save();EndMatch();}
  }
  bool AbandonedPickup(SnakePickup pickup){
   if(pickup.Age<30)return false;bool running=false;var position=pickup.transform.position;
   for(int slot=0;slot<setup.count;slot++)if(rules.Playing(slot)){running=true;if((trucks[slot].body.position-position).sqrMagnitude<900*900)return false;}
   if(!running)return false;
   // Never visibly move a live gate. The pool only retires old objectives far
   // behind every surviving train and outside every displayed gameplay view.
   if(cameras!=null)foreach(var camera in cameras)if(camera!=null&&camera.enabled){var p=camera.WorldToViewportPoint(position);if(p.z>0&&p.x>-.1f&&p.x<1.1f&&p.y>-.1f&&p.y<1.1f)return false;}
   return true;
  }
  void SpawnPickups(){foreach(var pickup in pickups){if(pickup.Live&&AbandonedPickup(pickup)){pickup.Dormant();RecycledPickups++;}if(!pickup.Live)for(int attempt=0;attempt<12;attempt++){int slot=random.Next(setup.count);if(!rules.Playing(slot))continue;Vector3 position=world.ReachablePickup(trucks[slot].body.position,trucks[slot].transform.forward,random,pickup.Golden);if(!world.PickupClear(position,trucks,convoys,pickups))continue;pickup.Spawn(position);break;}}}
  public bool Collect(SnakePickup pickup,int slot){if(!Live||Intro>0||!pickup.Live||!rules.Playing(slot))return false;int count=pickup.Golden?3:1;int before=rules.score[slot];if(!rules.Pickup(slot,pickup.Golden))return false;convoys[slot].Grow(count);pickup.Dormant();PhysicalPickups++;ConfirmScore("pickup:"+PhysicalPickups,slot,rules.score[slot]-before,rules.score[slot],count==1?"TRAILER COLLECTED":"GOLDEN TRAILER PICKUP",pickup.Golden?SportsScoreTier.Major:SportsScoreTier.Small);notice=setup.players[slot].name+" · +"+count+" TRAILER"+(count==1?"!":"S!");if(rules.trailers[slot]==10||rules.trailers[slot]==25||rules.trailers[slot]==50)notice=rules.trailers[slot]+" TRAILERS!";noticeUntil=Time.time+2;feedback.Play(5,0,true);Pulse(slot,.14f,.1f);return true;}
  public void Fail(int slot,string reason){if(!rules.Crash(slot))return;failure[slot]=reason;trucks[slot].Power(false);convoys[slot].Freeze();notice=setup.players[slot].name+" · "+reason;noticeUntil=Time.time+2;feedback.Play(0,15,true);}
  readonly UnityEngine.InputSystem.Key[,] extraKeys=new UnityEngine.InputSystem.Key[4,2];readonly bool[] previousCamera=new bool[4];
  void ConfigureKeys(){var used=new System.Collections.Generic.HashSet<UnityEngine.InputSystem.Key>{UnityEngine.InputSystem.Key.Escape,UnityEngine.InputSystem.Key.Enter};for(int i=0;i<setup.count;i++)if(setup.players[i].source==BowlingSource.Keyboard){used.Add(setup.players[i].forward);used.Add(setup.players[i].back);used.Add(setup.players[i].left);used.Add(setup.players[i].right);used.Add(actionKeys[i]);}var hornKeys=new[]{UnityEngine.InputSystem.Key.V,UnityEngine.InputSystem.Key.Home,UnityEngine.InputSystem.Key.Comma,UnityEngine.InputSystem.Key.Slash};var viewKeys=new[]{UnityEngine.InputSystem.Key.C,UnityEngine.InputSystem.Key.End,UnityEngine.InputSystem.Key.N,UnityEngine.InputSystem.Key.Semicolon};for(int i=0;i<setup.count;i++){previousCamera[i]=false;for(int k=0;k<2;k++){var key=k==0?hornKeys[i]:viewKeys[i];if(used.Contains(key))for(int candidate=(int)UnityEngine.InputSystem.Key.F1;candidate<=(int)UnityEngine.InputSystem.Key.F12;candidate++)if(!used.Contains((UnityEngine.InputSystem.Key)candidate)){key=(UnityEngine.InputSystem.Key)candidate;break;}extraKeys[i,k]=key;used.Add(key);}}}
  public override string ControlCaption(int slot){var p=setup.players[slot];return Controls(slot)+(p.source==BowlingSource.Keyboard?" · "+extraKeys[slot,0]+" HORN · "+extraKeys[slot,1]+" VIEW":p.source==BowlingSource.WholeController?" · L3 HORN · NORTH VIEW":p.Controller?" · SHOULDER HORN":"");}
  void HornAndView(int slot){var p=setup.players[slot];bool hornHeld=false,view=false;if(p.source==BowlingSource.Keyboard){hornHeld=SportsDeviceInput.KeyHeld(extraKeys[slot,0]);view=SportsDeviceInput.KeyHeld(extraKeys[slot,1]);}else if(p.Controller&&p.pad!=null){hornHeld=p.source==BowlingSource.WholeController?p.pad.leftStickButton.isPressed:p.source==BowlingSource.LeftStick?p.pad.leftShoulder.isPressed:p.pad.rightShoulder.isPressed;view=p.source==BowlingSource.WholeController&&p.pad.buttonNorth.isPressed;}if(view&&!previousCamera[slot]&&p.released)drivingViews.CycleParticipant(slot);previousCamera[slot]=view;if(hornHeld&&p.released&&Time.time>=nextHorn[slot]&&horn!=null){nextHorn[slot]=Time.time+Mathf.Max(.4f,horn.length*.8f);horns[slot].volume=settings.sfx*.65f;horns[slot].PlayOneShot(horn);}}

  public override void ExtraAction(string key){if(key=="drivingview")drivingViews.Cycle();}
  protected override void Present(float dt){if(drivingViews==null)return;drivingViews.Tick(dt);if(drivingViews.NeedsArena){int focus=0;for(int i=0;i<setup.count;i++)if(!rules.crashed[i]){focus=i;break;}broadcast.Pose(trucks[focus].body.position,new Vector3(0,30,-40),67);}else for(int v=0;v<drivingViews.rally.Humans;v++){int owner=drivingViews.rally.owners[v];if(!rules.crashed[owner])continue;int focus=owner;for(int i=0;i<setup.count;i++)if(!rules.crashed[i]){focus=i;break;}drivingViews.cabs[v].gameObject.SetActive(false);drivingViews.rally.views[v].Pose(trucks[focus].body.position,new Vector3(0,20,-30),67);}}
  protected override void StopGame(){if(trucks==null)return;foreach(var truck in trucks){truck.Power(false);truck.body.isKinematic=true;}foreach(var convoy in convoys)convoy.Freeze();}
  protected override void StopSounds(){if(trucks!=null)foreach(var truck in trucks)truck.StopSound();if(horns!=null)foreach(var audio in horns)if(audio!=null)audio.Stop();}
  protected override void SetPaused(bool pause){atmosphere?.Pause(pause);}
 }
}
